export type Service = {
  id: string;
  name: string;
  unit: string;
  price: number;
  icon: string;
  tint: string;
};

export type OrderStatus = "Proses" | "Selesai" | "Sudah Diambil";
export type PaymentStatus = "Lunas" | "Belum Lunas";
export type PaymentMethod = "Tunai" | "QRIS / E-Wallet" | "Transfer Bank";

export type LaundryOrder = {
  id: string;
  name: string;
  phone: string;
  service: string;
  quantity: number;
  amount: number;
  discount: number;
  payMethod: PaymentMethod;
  status: OrderStatus;
  payStatus: PaymentStatus;
  date: string;
  note: string;
};

export type Customer = {
  id: string;
  name: string;
  phone: string;
  address: string;
  type: "VIP" | "Reguler";
};

export type Promo = {
  id: string;
  code: string;
  name: string;
  discount: number;
  minOrder: number;
  expiry: string;
  status: "Aktif" | "Berakhir";
};

export type Expense = {
  id: string;
  name: string;
  amount: number;
  date: string;
};

export type Automation = {
  autoReply: boolean;
  customerNotification: boolean;
  detergentAlert: boolean;
};

export type ArmuznaState = {
  orders: LaundryOrder[];
  customers: Customer[];
  promos: Promo[];
  expenses: Expense[];
  isDark: boolean;
  isLoggedIn: boolean;
  notificationsEnabled: boolean;
  automation: Automation;
};

export const services: Service[] = [
  { id: "kiloan", name: "Cuci Kiloan", unit: "/ kg", price: 7000, icon: "scale", tint: "#38BDF8" },
  { id: "setrika", name: "Cuci Setrika", unit: "/ kg", price: 10000, icon: "checkroom", tint: "#FBBF24" },
  { id: "express", name: "Express 1 Hari", unit: "/ kg", price: 15000, icon: "bolt", tint: "#FB7185" },
  { id: "dry-clean", name: "Dry Clean", unit: "/ pcs", price: 30000, icon: "auto-fix-high", tint: "#22D3EE" },
  { id: "sepatu", name: "Cuci Sepatu", unit: "/ pasang", price: 25000, icon: "hiking", tint: "#34D399" },
  { id: "karpet", name: "Cuci Karpet", unit: "/ m²", price: 20000, icon: "texture", tint: "#818CF8" },
  { id: "bed-cover", name: "Bed Cover", unit: "/ pcs", price: 35000, icon: "bed", tint: "#C084FC" },
  { id: "sprei", name: "Cuci Sprei", unit: "/ pcs", price: 15000, icon: "layers", tint: "#2DD4BF" },
];

export const createSeedState = (): ArmuznaState => ({
  orders: [
    { id: "NOTA-101", name: "Armuzna Laundry", phone: "085927262579", service: "Cuci Setrika", quantity: 3, amount: 30000, discount: 0, payMethod: "Tunai", status: "Proses", payStatus: "Lunas", date: "2026-08-08", note: "Baju putih dipisah" },
    { id: "NOTA-102", name: "Achmad Efendi", phone: "0889009698", service: "Express 1 Hari", quantity: 3, amount: 45000, discount: 5000, payMethod: "QRIS / E-Wallet", status: "Selesai", payStatus: "Lunas", date: "2026-08-09", note: "-" },
  ],
  customers: [
    { id: "customer-1", name: "Armuzna Laundry", phone: "085927262579", address: "Jl. Utama No. 12, Jakarta", type: "VIP" },
    { id: "customer-2", name: "Achmad Efendi", phone: "0889009698", address: "Jl. Pemuda No. 45, Surabaya", type: "Reguler" },
  ],
  promos: [
    { id: "promo-101", code: "BERSIH5K", name: "Promo Hemat Rp 5.000", discount: 5000, minOrder: 20000, expiry: "2026-12-31", status: "Aktif" },
    { id: "promo-102", code: "MEMBERVIP", name: "Diskon Spesial VIP", discount: 10000, minOrder: 35000, expiry: "2026-12-31", status: "Aktif" },
  ],
  expenses: [],
  isDark: true,
  isLoggedIn: false,
  notificationsEnabled: false,
  automation: { autoReply: true, customerNotification: true, detergentAlert: true },
});

export const formatCurrency = (amount: number) =>
  `Rp ${Math.round(amount).toLocaleString("id-ID")}`;

export const todayISO = () => new Date().toISOString().slice(0, 10);

export const makeId = (prefix: string) => `${prefix}-${Date.now()}-${Math.round(Math.random() * 1000)}`;

export const findService = (name: string) =>
  services.find((service) => service.name === name) ?? services[0];

export const calculateOrderTotal = (serviceName: string, quantity: number, discount = 0) =>
  Math.max(0, findService(serviceName).price * Math.max(0, quantity) - Math.max(0, discount));
