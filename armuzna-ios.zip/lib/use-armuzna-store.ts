import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useMemo, useState } from "react";

import {
  type ArmuznaState,
  type Customer,
  createSeedState,
  type Expense,
  type LaundryOrder,
  makeId,
  type OrderStatus,
  type PaymentMethod,
  type PaymentStatus,
  type Promo,
  todayISO,
} from "@/lib/armuzna-data";

const STORAGE_KEY = "armuzna-local-state-v1";

type OrderInput = {
  name: string;
  phone: string;
  service: string;
  quantity: number;
  amount: number;
  discount: number;
  payMethod: PaymentMethod;
  payStatus: PaymentStatus;
  note: string;
};

type PromoInput = Omit<Promo, "id" | "status">;
type CustomerInput = Omit<Customer, "id">;
type ExpenseInput = Omit<Expense, "id">;

export function useArmuznaStore() {
  const [state, setState] = useState<ArmuznaState>(createSeedState);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!active || !raw) return;
        const parsed = JSON.parse(raw) as Partial<ArmuznaState>;
        if (Array.isArray(parsed.orders) && Array.isArray(parsed.customers) && Array.isArray(parsed.promos) && Array.isArray(parsed.expenses)) {
          setState((current) => ({ ...current, ...parsed }));
        }
      })
      .catch(() => undefined)
      .finally(() => {
        if (active) setHydrated(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state)).catch(() => undefined);
  }, [hydrated, state]);

  const metrics = useMemo(() => {
    const revenue = state.orders.reduce((total, order) => total + order.amount, 0);
    const expenses = state.expenses.reduce((total, expense) => total + expense.amount, 0);
    return {
      revenue,
      expenses,
      profit: revenue - expenses,
      unpaid: state.orders.filter((order) => order.payStatus === "Belum Lunas").length,
      vip: state.customers.filter((customer) => customer.type === "VIP").length,
      activePromos: state.promos.filter((promo) => promo.status === "Aktif").length,
    };
  }, [state]);

  const addOrder = (input: OrderInput) => {
    const existingNumbers = state.orders
      .map((order) => Number(order.id.replace("NOTA-", "")))
      .filter((number) => Number.isFinite(number));
    const nextNumber = Math.max(100, ...existingNumbers) + 1;
    const order: LaundryOrder = {
      id: `NOTA-${nextNumber}`,
      ...input,
      status: "Proses",
      date: todayISO(),
    };
    setState((current) => {
      const hasCustomer = current.customers.some(
        (customer) => customer.phone === input.phone || customer.name.toLowerCase() === input.name.toLowerCase(),
      );
      const nextCustomers = hasCustomer
        ? current.customers
        : [{ id: makeId("customer"), name: input.name, phone: input.phone, address: "-", type: "Reguler" as const }, ...current.customers];
      return { ...current, orders: [order, ...current.orders], customers: nextCustomers };
    });
    return order;
  };

  const updateOrderStatus = (id: string, status: OrderStatus) => {
    setState((current) => ({
      ...current,
      orders: current.orders.map((order) => (order.id === id ? { ...order, status } : order)),
    }));
  };

  const savePromo = (input: PromoInput, id?: string) => {
    setState((current) => {
      if (id) {
        return { ...current, promos: current.promos.map((promo) => (promo.id === id ? { ...promo, ...input } : promo)) };
      }
      return { ...current, promos: [{ id: makeId("promo"), ...input, status: "Aktif" }, ...current.promos] };
    });
  };

  const deletePromo = (id: string) => setState((current) => ({ ...current, promos: current.promos.filter((promo) => promo.id !== id) }));

  const saveCustomer = (input: CustomerInput, id?: string) => {
    setState((current) => {
      if (id) {
        return { ...current, customers: current.customers.map((customer) => (customer.id === id ? { ...customer, ...input } : customer)) };
      }
      return { ...current, customers: [{ id: makeId("customer"), ...input }, ...current.customers] };
    });
  };

  const deleteCustomer = (id: string) => setState((current) => ({ ...current, customers: current.customers.filter((customer) => customer.id !== id) }));

  const addExpense = (input: ExpenseInput) => setState((current) => ({ ...current, expenses: [{ id: makeId("expense"), ...input }, ...current.expenses] }));

  const deleteExpense = (id: string) => setState((current) => ({ ...current, expenses: current.expenses.filter((expense) => expense.id !== id) }));

  const updateSettings = (patch: Partial<Pick<ArmuznaState, "isDark" | "isLoggedIn" | "notificationsEnabled" | "automation">>) =>
    setState((current) => ({ ...current, ...patch }));

  return {
    state,
    hydrated,
    metrics,
    addOrder,
    updateOrderStatus,
    savePromo,
    deletePromo,
    saveCustomer,
    deleteCustomer,
    addExpense,
    deleteExpense,
    updateSettings,
  };
}
