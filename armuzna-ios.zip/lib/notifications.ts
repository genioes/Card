import { Platform } from "react-native";
import * as Notifications from "expo-notifications";

if (Platform.OS !== "web") {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldPlaySound: false,
      shouldSetBadge: false,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
}

export async function enableLocalNotifications() {
  if (Platform.OS === "web") return false;
  const current = await Notifications.getPermissionsAsync();
  const result = current.status === "granted" ? current : await Notifications.requestPermissionsAsync();
  return result.status === "granted";
}

export async function notifyLocal(title: string, body: string) {
  if (Platform.OS === "web") return false;
  const allowed = await enableLocalNotifications();
  if (!allowed) return false;
  await Notifications.scheduleNotificationAsync({ content: { title, body }, trigger: null });
  return true;
}
