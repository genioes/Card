import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useMemo, useState } from "react";
import { FlatList, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { CustomersScreen, ExpensesScreen, OrderScreen, PromosScreen, TrackingScreen } from "@/components/armuzna-operational-screens";
import { AiScreen, AnalyticsScreen, SettingsScreen } from "@/components/armuzna-insights-screens";
import { formatCurrency, services } from "@/lib/armuzna-data";
import { useArmuznaStore } from "@/lib/use-armuzna-store";

type ScreenKey = "home" | "orders" | "services" | "more" | "promos" | "customers" | "expenses" | "tracking" | "ai" | "analytics" | "settings";

type NavItem = { key: ScreenKey; label: string; icon: keyof typeof MaterialIcons.glyphMap };

const tabs: NavItem[] = [
  { key: "home", label: "Beranda", icon: "home-filled" },
  { key: "orders", label: "Kasir", icon: "receipt-long" },
  { key: "services", label: "Layanan", icon: "sell" },
  { key: "more", label: "Lainnya", icon: "grid-view" },
];

const moreItems: NavItem[] = [
  { key: "promos", label: "Promosi", icon: "campaign" },
  { key: "customers", label: "Pelanggan", icon: "groups" },
  { key: "expenses", label: "Pengeluaran", icon: "account-balance-wallet" },
  { key: "tracking", label: "Cek Status", icon: "search" },
  { key: "ai", label: "Agen AI", icon: "smart-toy" },
  { key: "analytics", label: "Analytics", icon: "insights" },
  { key: "settings", label: "Pengaturan", icon: "settings" },
];

export default function ArmuznaScreen() {
  const store = useArmuznaStore();
  const [screen, setScreen] = useState<ScreenKey>("home");
  const [selectedService, setSelectedService] = useState(services[0]);

  const colors = useMemo(
    () =>
      store.state.isDark
        ? { background: "#030712", surface: "#111827", surfaceSoft: "#172033", text: "#F8FAFC", muted: "#94A3B8", border: "#253047", tint: "#38BDF8" }
        : { background: "#F8FAFC", surface: "#FFFFFF", surfaceSoft: "#F1F5F9", text: "#0F172A", muted: "#64748B", border: "#E2E8F0", tint: "#0284C7" },
    [store.state.isDark],
  );

  const title = screen === "home" ? "Armuzna" : screen === "orders" ? "Kasir & Transaksi" : screen === "services" ? "Daftar Harga" : screen === "more" ? "Menu Lainnya" : moreItems.find((item) => item.key === screen)?.label ?? "Armuzna";

  const openService = (index: number) => {
    setSelectedService(services[index]);
    setScreen("orders");
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} style={{ backgroundColor: colors.background }}>
      <View style={[styles.header, { borderBottomColor: colors.border, backgroundColor: colors.background }]}>
        <View>
          <Text style={[styles.eyebrow, { color: colors.tint }]}>ARMUZNA LAUNDRY</Text>
          <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
        </View>
        <Pressable onPress={() => setScreen("settings")} style={({ pressed }) => [styles.profile, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}>
          <Text style={[styles.profileText, { color: colors.tint }]}>{store.state.isLoggedIn ? "AE" : "?"}</Text>
        </Pressable>
      </View>

      {screen === "home" && <HomePlaceholder colors={colors} revenue={store.metrics.revenue} orderCount={store.state.orders.length} onNavigate={setScreen} />}
      {screen === "orders" && <OrderScreen colors={colors} store={store} selectedService={selectedService.name} />}
      {screen === "services" && <ServicesScreen colors={colors} onSelect={openService} />}
      {screen === "more" && <MoreScreen colors={colors} onNavigate={setScreen} />}
      {screen === "promos" && <PromosScreen colors={colors} store={store} />}
      {screen === "customers" && <CustomersScreen colors={colors} store={store} />}
      {screen === "expenses" && <ExpensesScreen colors={colors} store={store} />}
      {screen === "tracking" && <TrackingScreen colors={colors} store={store} />}
      {screen === "ai" && <AiScreen colors={colors} store={store} />}
      {screen === "analytics" && <AnalyticsScreen colors={colors} store={store} />}
      {screen === "settings" && <SettingsScreen colors={colors} store={store} />}

      <View style={[styles.tabBar, { backgroundColor: colors.surface, borderTopColor: colors.border }]}>
        {tabs.map((item) => {
          const focused = screen === item.key || (item.key === "more" && moreItems.some((more) => more.key === screen));
          return (
            <Pressable key={item.key} onPress={() => setScreen(item.key)} style={({ pressed }) => [styles.tab, pressed && styles.pressed]}>
              <View style={[styles.tabIcon, focused && { backgroundColor: `${colors.tint}22` }]}>
                <MaterialIcons name={item.icon} size={22} color={focused ? colors.tint : colors.muted} />
              </View>
              <Text style={[styles.tabLabel, { color: focused ? colors.tint : colors.muted }]}>{item.label}</Text>
            </Pressable>
          );
        })}
      </View>
    </ScreenContainer>
  );
}

function HomePlaceholder({ colors, revenue, orderCount, onNavigate }: { colors: Record<string, string>; revenue: number; orderCount: number; onNavigate: (screen: ScreenKey) => void }) {
  return (
    <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
      <View style={[styles.hero, { borderColor: "#1E40AF", backgroundColor: "#0F1B3A" }]}>
        <Text style={[styles.heroPill, { color: "#7DD3FC" }]}>SISTEM LAUNDRY TERINTEGRASI</Text>
        <Text style={styles.heroTitle}>Semua aktivitas laundry, dalam genggaman.</Text>
        <Text style={styles.heroBody}>Kelola transaksi, pelanggan, promosi, dan keuangan dengan alur yang dirancang untuk operasional harian.</Text>
        <View style={styles.rowGap}>
          <Pressable onPress={() => onNavigate("orders")} style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]}>
            <MaterialIcons name="add-circle" size={18} color="#031127" />
            <Text style={styles.primaryButtonText}>Buat Transaksi</Text>
          </Pressable>
          <Pressable onPress={() => onNavigate("promos")} style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed]}>
            <Text style={styles.secondaryButtonText}>Kelola Promo</Text>
          </Pressable>
        </View>
      </View>
      <View style={styles.metricsRow}>
        <MetricCard label="Pendapatan" value={formatCurrency(revenue)} icon="trending-up" tint="#34D399" colors={colors} />
        <MetricCard label="Transaksi" value={`${orderCount} Nota`} icon="receipt-long" tint="#38BDF8" colors={colors} />
      </View>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.cardTitle, { color: colors.text }]}>Status Pengerjaan</Text>
        <Text style={[styles.muted, { color: colors.muted }]}>Pekerjaan aktif berdasarkan layanan populer.</Text>
        <StatusRow label="Cuci Kiloan" value="32%" tint="#38BDF8" colors={colors} />
        <StatusRow label="Cuci Setrika" value="43%" tint="#34D399" colors={colors} />
        <StatusRow label="Express 1 Hari" value="67%" tint="#FBBF24" colors={colors} />
      </View>
    </ScrollView>
  );
}

function ServicesScreen({ colors, onSelect }: { colors: Record<string, string>; onSelect: (index: number) => void }) {
  return (
    <FlatList
      data={services}
      numColumns={2}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.gridContent}
      columnWrapperStyle={styles.gridRow}
      renderItem={({ item, index }) => (
        <Pressable onPress={() => onSelect(index)} style={({ pressed }) => [styles.serviceCard, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}>
          <View style={[styles.serviceIcon, { backgroundColor: `${item.tint}20` }]}>
            <MaterialIcons name={item.icon as keyof typeof MaterialIcons.glyphMap} size={24} color={item.tint} />
          </View>
          <Text numberOfLines={1} style={[styles.serviceTitle, { color: colors.text }]}>{item.name}</Text>
          <Text style={[styles.servicePrice, { color: item.tint }]}>{formatCurrency(item.price)}</Text>
          <Text style={[styles.unit, { color: colors.muted }]}>{item.unit}</Text>
        </Pressable>
      )}
    />
  );
}

function MoreScreen({ colors, onNavigate }: { colors: Record<string, string>; onNavigate: (screen: ScreenKey) => void }) {
  return (
    <FlatList
      data={moreItems}
      numColumns={2}
      keyExtractor={(item) => item.key}
      contentContainerStyle={styles.gridContent}
      columnWrapperStyle={styles.gridRow}
      renderItem={({ item }) => (
        <Pressable onPress={() => onNavigate(item.key)} style={({ pressed }) => [styles.menuCard, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}>
          <MaterialIcons name={item.icon} size={26} color={colors.tint} />
          <Text style={[styles.menuTitle, { color: colors.text }]}>{item.label}</Text>
          <MaterialIcons name="chevron-right" size={18} color={colors.muted} />
        </Pressable>
      )}
    />
  );
}

function MetricCard({ label, value, icon, tint, colors }: { label: string; value: string; icon: keyof typeof MaterialIcons.glyphMap; tint: string; colors: Record<string, string> }) {
  return (
    <View style={[styles.metricCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <MaterialIcons name={icon} size={22} color={tint} />
      <Text style={[styles.metricLabel, { color: colors.muted }]}>{label}</Text>
      <Text style={[styles.metricValue, { color: colors.text }]} numberOfLines={1}>{value}</Text>
    </View>
  );
}

function StatusRow({ label, value, tint, colors }: { label: string; value: string; tint: string; colors: Record<string, string> }) {
  return (
    <View style={[styles.statusRow, { backgroundColor: colors.surfaceSoft }]}>
      <Text style={[styles.statusLabel, { color: colors.text }]}>{label}</Text>
      <Text style={[styles.statusValue, { color: tint }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  header: { height: 78, paddingHorizontal: 20, paddingBottom: 10, flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", borderBottomWidth: StyleSheet.hairlineWidth },
  eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 1.25, marginBottom: 3 },
  title: { fontSize: 28, lineHeight: 34, fontWeight: "800", letterSpacing: -0.6 },
  profile: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", borderWidth: 1 },
  profileText: { fontWeight: "800", fontSize: 13 },
  scrollContent: { padding: 20, gap: 16, paddingBottom: 104 },
  hero: { padding: 20, borderRadius: 24, borderWidth: 1, gap: 12 },
  heroPill: { fontSize: 10, fontWeight: "800", letterSpacing: 0.6 },
  heroTitle: { fontSize: 25, lineHeight: 31, color: "#F8FAFC", fontWeight: "800", letterSpacing: -0.4 },
  heroBody: { fontSize: 13, lineHeight: 20, color: "#CBD5E1" },
  rowGap: { flexDirection: "row", flexWrap: "wrap", gap: 9, marginTop: 4 },
  primaryButton: { backgroundColor: "#38BDF8", borderRadius: 14, paddingHorizontal: 14, paddingVertical: 11, flexDirection: "row", alignItems: "center", gap: 7 },
  primaryButtonText: { color: "#031127", fontSize: 12, fontWeight: "800" },
  secondaryButton: { borderColor: "#334155", borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 11, alignItems: "center", justifyContent: "center" },
  secondaryButtonText: { color: "#E2E8F0", fontSize: 12, fontWeight: "800" },
  metricsRow: { flexDirection: "row", gap: 12 },
  metricCard: { flex: 1, borderRadius: 18, borderWidth: 1, padding: 14, gap: 5 },
  metricLabel: { fontSize: 11, fontWeight: "600" },
  metricValue: { fontSize: 16, fontWeight: "800" },
  card: { borderRadius: 20, borderWidth: 1, padding: 16, gap: 8 },
  cardTitle: { fontSize: 16, fontWeight: "800" },
  muted: { fontSize: 12, lineHeight: 18 },
  statusRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 12, borderRadius: 14, marginTop: 3 },
  statusLabel: { fontSize: 12, fontWeight: "700" },
  statusValue: { fontSize: 13, fontWeight: "800" },
  pageCard: { margin: 20, alignItems: "center", textAlign: "center", gap: 12 },
  gridContent: { padding: 20, paddingBottom: 104, gap: 12 },
  gridRow: { gap: 12 },
  serviceCard: { flex: 1, minHeight: 156, borderRadius: 20, borderWidth: 1, padding: 14, justifyContent: "space-between" },
  serviceIcon: { width: 46, height: 46, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  serviceTitle: { fontSize: 13, fontWeight: "800", marginTop: 8 },
  servicePrice: { fontSize: 14, fontWeight: "800", marginTop: 7 },
  unit: { fontSize: 10, marginTop: 1 },
  menuCard: { flex: 1, minHeight: 120, borderRadius: 18, borderWidth: 1, padding: 14, justifyContent: "space-between" },
  menuTitle: { fontSize: 13, fontWeight: "800", marginTop: 4 },
  tabBar: { height: 76, flexDirection: "row", alignItems: "center", justifyContent: "space-around", borderTopWidth: StyleSheet.hairlineWidth, paddingBottom: 8, paddingTop: 6 },
  tab: { flex: 1, alignItems: "center", gap: 2 },
  tabIcon: { width: 40, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  tabLabel: { fontSize: 10, fontWeight: "700" },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
});
