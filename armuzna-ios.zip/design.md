# Rancangan Antarmuka Armuzna Laundry

## Sasaran Produk

Armuzna Laundry adalah panel operasional laundry dalam bentuk aplikasi iOS berorientasi potret. Aplikasi mengubah dashboard web pada dokumen referensi menjadi pengalaman satu tangan: navigasi utama berada di tab bar bawah, tindakan yang sering dilakukan dapat dijangkau dari bagian bawah layar, dan halaman input menggunakan lembar modal (sheet) yang mengikuti pola iOS.

## Screen List

| Layar | Konten utama | Fungsi utama |
|---|---|---|
| Beranda | Ringkasan pendapatan, transaksi, status cucian, arus kas, tindakan cepat | Melihat kondisi usaha dan masuk ke transaksi atau promosi |
| Kasir | Daftar transaksi, KPI kasir, pencarian dan filter | Meninjau dan memperbarui status transaksi |
| Transaksi Baru | Pelanggan, layanan, berat/jumlah, promo, pembayaran, catatan | Menghitung total, membuat nota, dan menambahkan pelanggan otomatis |
| Layanan | Kartu delapan layanan dan harga | Memilih layanan lalu membuka transaksi baru dengan layanan tersebut |
| Promosi | Statistik promo, daftar promo, tambah/edit promo | Mengelola voucher yang dapat dipakai di transaksi |
| Pelanggan | Statistik pelanggan, pencarian/filter, daftar pelanggan | Menambah, mengubah, dan menghapus pelanggan |
| Pengeluaran | Ringkasan total bulanan dan riwayat | Mencatat serta menghapus biaya operasional |
| Cek Status | Pencarian nomor nota atau WhatsApp dan kartu hasil | Menemukan status pesanan pelanggan |
| Agen AI | Percakapan, quick prompt, pengaturan otomatisasi | Menampilkan simulasi balasan dan pengaturan otomatisasi lokal |
| Analytics | KPI usaha dan grafik ringkas | Menampilkan tren pemasukan, pengeluaran, layanan, jam sibuk, dan kinerja |
| Akun & Pengaturan | Tema, notifikasi, masuk/daftar, keluar | Mengatur preferensi dan status autentikasi simulasi |

## Pola Tata Letak iOS

Setiap layar menggunakan area aman, latar gelap `#030712`, dan panel slate transparan agar menjaga karakter referensi. Header memakai judul besar iOS dan satu tindakan konteks; daftar memakai kartu beradius 18–24 px, bukan tabel desktop horizontal. Tab bar bawah menampilkan **Beranda**, **Kasir**, **Layanan**, **Lainnya**, sementara layar lain dibuka melalui menu Lainnya atau tombol tindakan cepat. Halaman yang kompleks seperti promo, pelanggan, dan pengeluaran menggunakan daftar ringkas dengan sheet untuk formulir tambah dan edit.

## Alur Utama

| Alur | Urutan interaksi |
|---|---|
| Membuat transaksi | Beranda/Kasir → tombol tambah → pilih atau konfirmasi pelanggan → pilih layanan → isi berat dan diskon/promo → tentukan pembayaran → simpan → nota baru tampil pada daftar dan pelanggan baru dibuat jika perlu |
| Memakai layanan dari daftar harga | Layanan → ketuk kartu layanan → Transaksi Baru → layanan sudah dipilih dan total dihitung |
| Mengelola promo | Lainnya → Promosi → tambah atau pilih promo → simpan → promo tersedia pada Transaksi Baru |
| Mengelola pelanggan | Lainnya → Pelanggan → tambah atau ketuk pelanggan → ubah/hapus → daftar dan statistik diperbarui |
| Mencatat biaya | Lainnya → Pengeluaran → tambah biaya → simpan → total bulan dan riwayat diperbarui |
| Melacak cucian | Lainnya → Cek Status → masukkan nomor nota atau WhatsApp → lihat kartu status transaksi |
| Berkonsultasi dengan AI | Lainnya → Agen AI → ketuk quick prompt atau tulis pesan → aplikasi menampilkan balasan simulasi dan menyimpan riwayat selama sesi |

## Pilihan Warna

| Peran | Warna | Penerapan |
|---|---|---|
| Latar utama | `#030712` | Semua layar dalam mode gelap |
| Panel | `#111827` | Kartu ringkasan, formulir, dan daftar |
| Aksen primer | `#38BDF8` | CTA transaksi, status proses, dan tautan |
| Indigo | `#6366F1` | Pengeluaran, grafik dan label pendukung |
| Emerald | `#34D399` | Pendapatan, pembayaran lunas dan status berhasil |
| Amber | `#FBBF24` | Promo, pelanggan VIP, dan penanda perhatian |
| Rose | `#FB7185` | Penghapusan dan pengeluaran |
| Teks sekunder | `#94A3B8` | Label, keterangan, dan metadata |

## Data dan Batasan

Versi awal menggunakan penyimpanan lokal pada perangkat. Data contoh dari dokumen referensi dipakai hanya untuk mengilustrasikan alur awal dan dapat diubah melalui aplikasi. Otentikasi serta agen AI mengikuti perilaku simulasi referensi; keduanya tidak mengirim data ke layanan luar.
