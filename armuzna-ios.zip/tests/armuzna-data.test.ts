import { describe, expect, it } from "vitest";

import { calculateOrderTotal, createSeedState, findService, formatCurrency, services } from "../lib/armuzna-data";

describe("Armuzna domain data", () => {
  it("memuat katalog delapan layanan dari referensi", () => {
    expect(services).toHaveLength(8);
    expect(findService("Express 1 Hari").price).toBe(15000);
  });

  it("menghitung total transaksi dan menjaga nilai tidak negatif", () => {
    expect(calculateOrderTotal("Cuci Kiloan", 3, 5000)).toBe(16000);
    expect(calculateOrderTotal("Dry Clean", 1, 50000)).toBe(0);
  });

  it("menyediakan data awal operasional dan format rupiah Indonesia", () => {
    const state = createSeedState();
    expect(state.orders.map((order) => order.id)).toEqual(["NOTA-101", "NOTA-102"]);
    expect(state.customers).toHaveLength(2);
    expect(formatCurrency(35000)).toBe("Rp 35.000");
  });
});
