# Project TODO

- [x] Membuat fondasi domain data laundry dan penyimpanan lokal
- [x] Menerapkan tab bar iOS serta navigasi seluruh modul referensi
- [x] Menerapkan dashboard beranda dengan tindakan cepat dan ringkasan
- [x] Menerapkan katalog delapan layanan dan penerusan ke transaksi
- [x] Menerapkan kasir, kalkulasi total, promo, status pembayaran, dan riwayat transaksi
- [x] Menerapkan CRUD promosi
- [x] Menerapkan CRUD pelanggan dan pelanggan otomatis dari transaksi
- [x] Menerapkan pencatatan dan penghapusan pengeluaran
- [x] Menerapkan cek status berdasarkan nota atau WhatsApp
- [x] Menerapkan agen AI simulasi, quick prompt, dan sakelar otomatisasi lokal
- [x] Menerapkan layar analytics dan visualisasi ringkas
- [x] Menerapkan pengaturan tema, notifikasi lokal, dan autentikasi simulasi
- [x] Membuat ikon Armuzna khusus dan memperbarui konfigurasi branding
- [x] Menambahkan pengujian unit alur operasi utama
- [x] Memeriksa tipe, lint, dan perilaku UI pada ukuran mobile
- [x] Memulihkan layanan pengembangan setelah pratinjau berhenti merespons
