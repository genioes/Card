import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useEffect, useState } from "react";
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import { calculateOrderTotal, type Customer, findService, formatCurrency, type LaundryOrder, type OrderStatus, type PaymentMethod, type PaymentStatus, type Promo, services, todayISO } from "@/lib/armuzna-data";
import { useArmuznaStore } from "@/lib/use-armuzna-store";

type Colors = Record<string, string>;
type Store = ReturnType<typeof useArmuznaStore>;

export function OrderScreen({ colors, store, selectedService }: { colors: Colors; store: Store; selectedService: string }) {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<"Semua" | OrderStatus>("Semua");
  const [showComposer, setShowComposer] = useState(false);
  const orders = store.state.orders.filter((order) => {
    const matchesQuery = order.id.toLowerCase().includes(query.toLowerCase()) || order.name.toLowerCase().includes(query.toLowerCase());
    return matchesQuery && (status === "Semua" || order.status === status);
  });

  return (
    <View style={styles.fill}>
      <FlatList
        data={orders}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <>
            <View style={styles.metricsRow}>
              <SmallMetric label="Total Nota" value={`${store.state.orders.length}`} icon="receipt-long" tint="#38BDF8" colors={colors} />
              <SmallMetric label="Omset" value={formatCurrency(store.metrics.revenue)} icon="trending-up" tint="#34D399" colors={colors} />
              <SmallMetric label="Belum Lunas" value={`${store.metrics.unpaid}`} icon="schedule" tint="#FBBF24" colors={colors} />
            </View>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>Kelola Transaksi</Text>
              <Pressable onPress={() => setShowComposer(true)} style={({ pressed }) => [styles.roundAction, { backgroundColor: colors.tint }, pressed && styles.pressed]}>
                <MaterialIcons name="add" size={22} color="#07111F" />
              </Pressable>
            </View>
            <TextInput value={query} onChangeText={setQuery} placeholder="Cari nota atau nama…" placeholderTextColor={colors.muted} style={[styles.search, { color: colors.text, backgroundColor: colors.surface, borderColor: colors.border }]} />
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>
              {(["Semua", "Proses", "Selesai", "Sudah Diambil"] as const).map((item) => <ChoiceChip key={item} label={item} selected={status === item} colors={colors} onPress={() => setStatus(item)} />)}
            </ScrollView>
          </>
        }
        renderItem={({ item }) => <OrderCard order={item} colors={colors} onAdvance={() => store.updateOrderStatus(item.id, nextStatus(item.status))} />}
        ListEmptyComponent={<EmptyState colors={colors} icon="search-off" message="Tidak ada transaksi yang sesuai." />}
      />
      <OrderComposer visible={showComposer} colors={colors} store={store} initialService={selectedService} onClose={() => setShowComposer(false)} />
    </View>
  );
}

export function PromosScreen({ colors, store }: { colors: Colors; store: Store }) {
  const [showComposer, setShowComposer] = useState(false);
  const [editing, setEditing] = useState<Promo | undefined>();
  const beginEdit = (promo?: Promo) => {
    setEditing(promo);
    setShowComposer(true);
  };
  return (
    <View style={styles.fill}>
      <FlatList
        data={store.state.promos}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <>
            <View style={[styles.featureMetric, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View>
                <Text style={[styles.metricLabel, { color: colors.muted }]}>PROMO AKTIF</Text>
                <Text style={[styles.featureMetricValue, { color: "#FBBF24" }]}>{store.metrics.activePromos} Promo</Text>
              </View>
              <MaterialIcons name="campaign" size={30} color="#FBBF24" />
            </View>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>Promosi & Diskon</Text>
              <Pressable onPress={() => beginEdit()} style={({ pressed }) => [styles.roundAction, { backgroundColor: "#FBBF24" }, pressed && styles.pressed]}>
                <MaterialIcons name="add" size={22} color="#1A1200" />
              </Pressable>
            </View>
          </>
        }
        renderItem={({ item }) => (
          <View style={[styles.rowCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.iconBox, { backgroundColor: "#FBBF2420" }]}><MaterialIcons name="local-offer" size={22} color="#FBBF24" /></View>
            <View style={styles.rowContent}>
              <Text style={[styles.rowTitle, { color: colors.text }]}>{item.code}</Text>
              <Text style={[styles.rowSub, { color: colors.muted }]} numberOfLines={1}>{item.name}</Text>
              <Text style={[styles.rowSub, { color: "#34D399" }]}>{formatCurrency(item.discount)} · min. {formatCurrency(item.minOrder)}</Text>
            </View>
            <Pressable onPress={() => beginEdit(item)} style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}><MaterialIcons name="edit" size={20} color={colors.tint} /></Pressable>
            <Pressable onPress={() => confirmDelete("Hapus promosi ini?", () => store.deletePromo(item.id))} style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}><MaterialIcons name="delete-outline" size={20} color="#FB7185" /></Pressable>
          </View>
        )}
        ListEmptyComponent={<EmptyState colors={colors} icon="campaign" message="Belum ada promosi aktif." />}
      />
      <PromoComposer visible={showComposer} colors={colors} value={editing} onClose={() => setShowComposer(false)} onSave={(input) => { store.savePromo(input, editing?.id); setShowComposer(false); }} />
    </View>
  );
}

export function CustomersScreen({ colors, store }: { colors: Colors; store: Store }) {
  const [query, setQuery] = useState("");
  const [type, setType] = useState<"Semua" | Customer["type"]>("Semua");
  const [showComposer, setShowComposer] = useState(false);
  const [editing, setEditing] = useState<Customer | undefined>();
  const customers = store.state.customers.filter((customer) => {
    const normalized = query.toLowerCase();
    return (type === "Semua" || customer.type === type) && [customer.name, customer.phone, customer.address].some((value) => value.toLowerCase().includes(normalized));
  });
  const open = (customer?: Customer) => { setEditing(customer); setShowComposer(true); };
  return (
    <View style={styles.fill}>
      <FlatList
        data={customers}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <>
            <View style={styles.metricsRow}>
              <SmallMetric label="Total" value={`${store.state.customers.length}`} icon="groups" tint="#38BDF8" colors={colors} />
              <SmallMetric label="VIP" value={`${store.metrics.vip}`} icon="workspace-premium" tint="#FBBF24" colors={colors} />
              <SmallMetric label="Reguler" value={`${store.state.customers.length - store.metrics.vip}`} icon="person" tint="#818CF8" colors={colors} />
            </View>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>Membership Pelanggan</Text>
              <Pressable onPress={() => open()} style={({ pressed }) => [styles.roundAction, { backgroundColor: colors.tint }, pressed && styles.pressed]}><MaterialIcons name="person-add" size={20} color="#07111F" /></Pressable>
            </View>
            <TextInput value={query} onChangeText={setQuery} placeholder="Cari nama, WhatsApp, alamat…" placeholderTextColor={colors.muted} style={[styles.search, { color: colors.text, backgroundColor: colors.surface, borderColor: colors.border }]} />
            <View style={styles.filterRow}>
              {(["Semua", "VIP", "Reguler"] as const).map((item) => <ChoiceChip key={item} label={item} selected={type === item} colors={colors} onPress={() => setType(item)} />)}
            </View>
          </>
        }
        renderItem={({ item }) => {
          const orderCount = store.state.orders.filter((order) => order.phone === item.phone).length;
          return <CustomerCard customer={item} orderCount={orderCount} colors={colors} onEdit={() => open(item)} onDelete={() => confirmDelete("Hapus pelanggan ini?", () => store.deleteCustomer(item.id))} />;
        }}
        ListEmptyComponent={<EmptyState colors={colors} icon="person-search" message="Tidak ada pelanggan yang sesuai." />}
      />
      <CustomerComposer visible={showComposer} colors={colors} value={editing} onClose={() => setShowComposer(false)} onSave={(input) => { store.saveCustomer(input, editing?.id); setShowComposer(false); }} />
    </View>
  );
}

export function ExpensesScreen({ colors, store }: { colors: Colors; store: Store }) {
  const [showComposer, setShowComposer] = useState(false);
  return (
    <View style={styles.fill}>
      <FlatList
        data={store.state.expenses}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <>
            <View style={[styles.featureMetric, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View><Text style={[styles.metricLabel, { color: colors.muted }]}>TOTAL PENGELUARAN</Text><Text style={[styles.featureMetricValue, { color: "#818CF8" }]}>{formatCurrency(store.metrics.expenses)}</Text></View>
              <MaterialIcons name="account-balance-wallet" size={30} color="#818CF8" />
            </View>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>Catatan Pengeluaran</Text>
              <Pressable onPress={() => setShowComposer(true)} style={({ pressed }) => [styles.roundAction, { backgroundColor: "#818CF8" }, pressed && styles.pressed]}><MaterialIcons name="add" size={22} color="#FFFFFF" /></Pressable>
            </View>
          </>
        }
        renderItem={({ item }) => <ExpenseCard expense={item} colors={colors} onDelete={() => confirmDelete("Hapus catatan pengeluaran ini?", () => store.deleteExpense(item.id))} />}
        ListEmptyComponent={<EmptyState colors={colors} icon="receipt" message="Belum ada pengeluaran tercatat." />}
      />
      <ExpenseComposer visible={showComposer} colors={colors} onClose={() => setShowComposer(false)} onSave={(input) => { store.addExpense(input); setShowComposer(false); }} />
    </View>
  );
}

export function TrackingScreen({ colors, store }: { colors: Colors; store: Store }) {
  const [query, setQuery] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const results = store.state.orders.filter((order) => order.id.toLowerCase().includes(query.toLowerCase()) || order.phone.includes(query));
  return (
    <ScrollView contentContainerStyle={styles.listContent} keyboardShouldPersistTaps="handled">
      <View style={[styles.trackingHero, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <View style={[styles.trackingIcon, { backgroundColor: `${colors.tint}20` }]}><MaterialIcons name="search" size={30} color={colors.tint} /></View>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Cek Status Cucian</Text>
        <Text style={[styles.centerMuted, { color: colors.muted }]}>Masukkan nomor nota atau nomor WhatsApp yang terdaftar.</Text>
        <TextInput value={query} onChangeText={setQuery} placeholder="NOTA-101 atau 08…" placeholderTextColor={colors.muted} style={[styles.search, { color: colors.text, backgroundColor: colors.surfaceSoft, borderColor: colors.border, alignSelf: "stretch" }]} />
        <Pressable onPress={() => setSubmitted(true)} style={({ pressed }) => [styles.primaryWide, { backgroundColor: colors.tint }, pressed && styles.pressed]}><Text style={styles.primaryWideText}>Cari Status</Text></Pressable>
      </View>
      {submitted && (results.length ? results.map((order) => <TrackingCard key={order.id} order={order} colors={colors} />) : <EmptyState colors={colors} icon="search-off" message="Transaksi tidak ditemukan." />)}
    </ScrollView>
  );
}

function OrderComposer({ visible, colors, store, initialService, onClose }: { visible: boolean; colors: Colors; store: Store; initialService: string; onClose: () => void }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [serviceName, setServiceName] = useState(initialService);
  const [quantity, setQuantity] = useState("1");
  const [promo, setPromo] = useState<Promo | undefined>();
  const [payMethod, setPayMethod] = useState<PaymentMethod>("Tunai");
  const [payStatus, setPayStatus] = useState<PaymentStatus>("Lunas");
  const [note, setNote] = useState("");
  useEffect(() => setServiceName(initialService), [initialService]);
  const service = findService(serviceName);
  const amount = calculateOrderTotal(service.name, Number(quantity) || 0, promo?.discount ?? 0);
  const save = () => {
    if (!name.trim() || !phone.trim()) { Alert.alert("Data belum lengkap", "Nama pelanggan dan nomor WhatsApp wajib diisi."); return; }
    store.addOrder({ name: name.trim(), phone: phone.trim(), service: service.name, quantity: Number(quantity) || 1, amount, discount: promo?.discount ?? 0, payMethod, payStatus, note: note.trim() || "-" });
    Alert.alert("Transaksi tersimpan", "Nota baru telah dibuat dan pelanggan otomatis ditambahkan bila belum tersedia.");
    onClose();
  };
  return <Sheet visible={visible} colors={colors} title="Transaksi Baru" onClose={onClose}>
    <FormField label="Nama Pelanggan" value={name} onChangeText={setName} placeholder="Nama pelanggan" colors={colors} />
    <FormField label="No. WhatsApp" value={phone} onChangeText={setPhone} placeholder="08xxxxxxxxxx" keyboardType="phone-pad" colors={colors} />
    <Label text="Pilih Layanan" colors={colors} />
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>{services.map((item) => <ChoiceChip key={item.id} label={item.name} selected={item.name === serviceName} colors={colors} onPress={() => setServiceName(item.name)} />)}</ScrollView>
    <FormField label={`Jumlah / Berat (${service.unit.trim()})`} value={quantity} onChangeText={setQuantity} placeholder="1" keyboardType="decimal-pad" colors={colors} />
    <Label text="Pilih Promo" colors={colors} />
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}><ChoiceChip label="Tanpa Promo" selected={!promo} colors={colors} onPress={() => setPromo(undefined)} />{store.state.promos.filter((item) => item.status === "Aktif" && item.minOrder <= service.price * (Number(quantity) || 0)).map((item) => <ChoiceChip key={item.id} label={item.code} selected={promo?.id === item.id} colors={colors} onPress={() => setPromo(item)} />)}</ScrollView>
    <Label text="Metode Bayar" colors={colors} />
    <View style={styles.wrapRow}>{(["Tunai", "QRIS / E-Wallet", "Transfer Bank"] as PaymentMethod[]).map((item) => <ChoiceChip key={item} label={item} selected={payMethod === item} colors={colors} onPress={() => setPayMethod(item)} />)}</View>
    <View style={styles.wrapRow}>{(["Lunas", "Belum Lunas"] as PaymentStatus[]).map((item) => <ChoiceChip key={item} label={item} selected={payStatus === item} colors={colors} onPress={() => setPayStatus(item)} />)}</View>
    <FormField label="Catatan" value={note} onChangeText={setNote} placeholder="Catatan khusus…" colors={colors} />
    <View style={[styles.totalBox, { backgroundColor: `${colors.tint}18`, borderColor: `${colors.tint}55` }]}><Text style={[styles.metricLabel, { color: colors.muted }]}>TOTAL AKHIR</Text><Text style={[styles.totalValue, { color: colors.tint }]}>{formatCurrency(amount)}</Text></View>
    <PrimaryAction label="Simpan Transaksi" colors={colors} onPress={save} />
  </Sheet>;
}

function PromoComposer({ visible, colors, value, onClose, onSave }: { visible: boolean; colors: Colors; value?: Promo; onClose: () => void; onSave: (input: Omit<Promo, "id" | "status">) => void }) {
  const [code, setCode] = useState(""); const [name, setName] = useState(""); const [discount, setDiscount] = useState(""); const [minimum, setMinimum] = useState(""); const [expiry, setExpiry] = useState(todayISO());
  useEffect(() => { setCode(value?.code ?? ""); setName(value?.name ?? ""); setDiscount(value ? String(value.discount) : ""); setMinimum(value ? String(value.minOrder) : ""); setExpiry(value?.expiry ?? todayISO()); }, [value, visible]);
  const save = () => { if (!code.trim() || !name.trim() || !discount.trim()) { Alert.alert("Data belum lengkap", "Kode, nama, dan potongan wajib diisi."); return; } onSave({ code: code.trim().toUpperCase(), name: name.trim(), discount: Number(discount) || 0, minOrder: Number(minimum) || 0, expiry }); };
  return <Sheet visible={visible} colors={colors} title={value ? "Edit Promosi" : "Buat Promosi"} onClose={onClose}><FormField label="Kode Voucher" value={code} onChangeText={setCode} placeholder="BERSIH5K" colors={colors} autoCapitalize="characters" /><FormField label="Nama Program" value={name} onChangeText={setName} placeholder="Promo Hemat" colors={colors} /><FormField label="Potongan (Rp)" value={discount} onChangeText={setDiscount} keyboardType="number-pad" placeholder="5000" colors={colors} /><FormField label="Minimum Order (Rp)" value={minimum} onChangeText={setMinimum} keyboardType="number-pad" placeholder="20000" colors={colors} /><FormField label="Berlaku sampai" value={expiry} onChangeText={setExpiry} placeholder="YYYY-MM-DD" colors={colors} /><PrimaryAction label="Simpan Promosi" colors={colors} onPress={save} /></Sheet>;
}

function CustomerComposer({ visible, colors, value, onClose, onSave }: { visible: boolean; colors: Colors; value?: Customer; onClose: () => void; onSave: (input: Omit<Customer, "id">) => void }) {
  const [name, setName] = useState(""); const [phone, setPhone] = useState(""); const [address, setAddress] = useState(""); const [type, setType] = useState<Customer["type"]>("Reguler");
  useEffect(() => { setName(value?.name ?? ""); setPhone(value?.phone ?? ""); setAddress(value?.address === "-" ? "" : value?.address ?? ""); setType(value?.type ?? "Reguler"); }, [value, visible]);
  const save = () => { if (!name.trim() || !phone.trim()) { Alert.alert("Data belum lengkap", "Nama dan nomor WhatsApp wajib diisi."); return; } onSave({ name: name.trim(), phone: phone.trim(), address: address.trim() || "-", type }); };
  return <Sheet visible={visible} colors={colors} title={value ? "Edit Pelanggan" : "Tambah Pelanggan"} onClose={onClose}><FormField label="Nama Lengkap" value={name} onChangeText={setName} placeholder="Nama pelanggan" colors={colors} /><FormField label="No. WhatsApp" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="08xxxxxxxxxx" colors={colors} /><Label text="Tipe Pelanggan" colors={colors} /><View style={styles.wrapRow}>{(["Reguler", "VIP"] as Customer["type"][]).map((item) => <ChoiceChip key={item} label={item} selected={type === item} colors={colors} onPress={() => setType(item)} />)}</View><FormField label="Alamat" value={address} onChangeText={setAddress} placeholder="Alamat rumah atau domisili" colors={colors} multiline /><PrimaryAction label="Simpan Pelanggan" colors={colors} onPress={save} /></Sheet>;
}

function ExpenseComposer({ visible, colors, onClose, onSave }: { visible: boolean; colors: Colors; onClose: () => void; onSave: (input: { name: string; amount: number; date: string }) => void }) {
  const [name, setName] = useState(""); const [amount, setAmount] = useState(""); const [date, setDate] = useState(todayISO());
  useEffect(() => { if (visible) { setName(""); setAmount(""); setDate(todayISO()); } }, [visible]);
  const save = () => { if (!name.trim() || !amount.trim()) { Alert.alert("Data belum lengkap", "Deskripsi dan nominal wajib diisi."); return; } onSave({ name: name.trim(), amount: Number(amount) || 0, date }); };
  return <Sheet visible={visible} colors={colors} title="Catat Pengeluaran" onClose={onClose}><FormField label="Deskripsi" value={name} onChangeText={setName} placeholder="Beli deterjen atau listrik" colors={colors} /><FormField label="Nominal (Rp)" value={amount} onChangeText={setAmount} keyboardType="number-pad" placeholder="50000" colors={colors} /><FormField label="Tanggal" value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" colors={colors} /><PrimaryAction label="Tambah Pengeluaran" colors={colors} onPress={save} /></Sheet>;
}

function Sheet({ visible, colors, title, onClose, children }: { visible: boolean; colors: Colors; title: string; onClose: () => void; children: React.ReactNode }) {
  return <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}><KeyboardAvoidingView style={styles.sheetOverlay} behavior={Platform.OS === "ios" ? "padding" : undefined}><Pressable style={styles.backdrop} onPress={onClose} /><View style={[styles.sheet, { backgroundColor: colors.background, borderColor: colors.border }]}><View style={styles.sheetHeader}><Text style={[styles.sheetTitle, { color: colors.text }]}>{title}</Text><Pressable onPress={onClose} style={[styles.closeButton, { backgroundColor: colors.surfaceSoft }]}><MaterialIcons name="close" size={20} color={colors.text} /></Pressable></View><ScrollView contentContainerStyle={styles.sheetContent} keyboardShouldPersistTaps="handled">{children}</ScrollView></View></KeyboardAvoidingView></Modal>;
}

function FormField({ label, value, onChangeText, placeholder, colors, keyboardType, multiline, autoCapitalize }: { label: string; value: string; onChangeText: (value: string) => void; placeholder: string; colors: Colors; keyboardType?: "default" | "phone-pad" | "number-pad" | "decimal-pad"; multiline?: boolean; autoCapitalize?: "none" | "sentences" | "words" | "characters" }) {
  return <View style={styles.field}><Label text={label} colors={colors} /><TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor={colors.muted} keyboardType={keyboardType} autoCapitalize={autoCapitalize} multiline={multiline} style={[styles.input, multiline && styles.textarea, { color: colors.text, backgroundColor: colors.surface, borderColor: colors.border }]} /></View>;
}

function Label({ text, colors }: { text: string; colors: Colors }) { return <Text style={[styles.label, { color: colors.muted }]}>{text}</Text>; }
function PrimaryAction({ label, colors, onPress }: { label: string; colors: Colors; onPress: () => void }) { return <Pressable onPress={onPress} style={({ pressed }) => [styles.primaryWide, { backgroundColor: colors.tint }, pressed && styles.pressed]}><Text style={styles.primaryWideText}>{label}</Text></Pressable>; }
function ChoiceChip({ label, selected, colors, onPress }: { label: string; selected: boolean; colors: Colors; onPress: () => void }) { return <Pressable onPress={onPress} style={({ pressed }) => [styles.choiceChip, { borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? `${colors.tint}22` : colors.surface }, pressed && styles.pressed]}><Text style={[styles.choiceText, { color: selected ? colors.tint : colors.muted }]}>{label}</Text></Pressable>; }
function EmptyState({ colors, icon, message }: { colors: Colors; icon: keyof typeof MaterialIcons.glyphMap; message: string }) { return <View style={[styles.empty, { backgroundColor: colors.surface, borderColor: colors.border }]}><MaterialIcons name={icon} size={28} color={colors.muted} /><Text style={[styles.centerMuted, { color: colors.muted }]}>{message}</Text></View>; }

function SmallMetric({ label, value, icon, tint, colors }: { label: string; value: string; icon: keyof typeof MaterialIcons.glyphMap; tint: string; colors: Colors }) { return <View style={[styles.smallMetric, { backgroundColor: colors.surface, borderColor: colors.border }]}><MaterialIcons name={icon} size={19} color={tint} /><Text style={[styles.metricLabel, { color: colors.muted }]} numberOfLines={1}>{label}</Text><Text style={[styles.smallMetricValue, { color: colors.text }]} numberOfLines={1}>{value}</Text></View>; }
function OrderCard({ order, colors, onAdvance }: { order: LaundryOrder; colors: Colors; onAdvance: () => void }) { const color = order.status === "Proses" ? "#38BDF8" : order.status === "Selesai" ? "#34D399" : "#94A3B8"; return <View style={[styles.orderCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={styles.orderTop}><View><Text style={[styles.orderId, { color: colors.tint }]}>{order.id}</Text><Text style={[styles.rowSub, { color: colors.muted }]}>{order.date} · {order.payMethod}</Text></View><Pressable onPress={onAdvance} style={[styles.statusPill, { backgroundColor: `${color}22` }]}><Text style={[styles.statusText, { color }]}>{order.status}</Text></Pressable></View><Text style={[styles.orderName, { color: colors.text }]}>{order.name}</Text><Text style={[styles.rowSub, { color: colors.muted }]}>{order.phone} · {order.service}</Text><View style={styles.orderFooter}><Text style={[styles.orderAmount, { color: "#34D399" }]}>{formatCurrency(order.amount)}</Text><Text style={[styles.payStatus, { color: order.payStatus === "Lunas" ? "#34D399" : "#FBBF24" }]}>{order.payStatus}</Text></View></View>; }
function CustomerCard({ customer, orderCount, colors, onEdit, onDelete }: { customer: Customer; orderCount: number; colors: Colors; onEdit: () => void; onDelete: () => void }) { const tint = customer.type === "VIP" ? "#FBBF24" : "#818CF8"; return <View style={[styles.rowCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={[styles.iconBox, { backgroundColor: `${tint}20` }]}><MaterialIcons name={customer.type === "VIP" ? "workspace-premium" : "person"} size={22} color={tint} /></View><View style={styles.rowContent}><Text style={[styles.rowTitle, { color: colors.text }]}>{customer.name}</Text><Text style={[styles.rowSub, { color: colors.muted }]}>{customer.phone}</Text><Text style={[styles.rowSub, { color: tint }]}>{customer.type} · {orderCount} Nota</Text></View><Pressable onPress={onEdit} style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}><MaterialIcons name="edit" size={20} color={colors.tint} /></Pressable><Pressable onPress={onDelete} style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}><MaterialIcons name="delete-outline" size={20} color="#FB7185" /></Pressable></View>; }
function ExpenseCard({ expense, colors, onDelete }: { expense: { id: string; name: string; amount: number; date: string }; colors: Colors; onDelete: () => void }) { return <View style={[styles.rowCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={[styles.iconBox, { backgroundColor: "#FB718520" }]}><MaterialIcons name="receipt" size={22} color="#FB7185" /></View><View style={styles.rowContent}><Text style={[styles.rowTitle, { color: colors.text }]}>{expense.name}</Text><Text style={[styles.rowSub, { color: colors.muted }]}>{expense.date}</Text><Text style={[styles.rowSub, { color: "#FB7185" }]}>{formatCurrency(expense.amount)}</Text></View><Pressable onPress={onDelete} style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}><MaterialIcons name="delete-outline" size={20} color="#FB7185" /></Pressable></View>; }
function TrackingCard({ order, colors }: { order: LaundryOrder; colors: Colors }) { const color = order.status === "Proses" ? "#38BDF8" : order.status === "Selesai" ? "#34D399" : "#94A3B8"; return <View style={[styles.trackingCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={styles.orderTop}><View><Text style={[styles.orderId, { color: colors.tint }]}>{order.id}</Text><Text style={[styles.rowSub, { color: colors.muted }]}>{order.date}</Text></View><View style={[styles.statusPill, { backgroundColor: `${color}22` }]}><Text style={[styles.statusText, { color }]}>{order.status}</Text></View></View><View style={styles.detailsGrid}><Detail label="Pelanggan" value={order.name} colors={colors} /><Detail label="Layanan" value={order.service} colors={colors} /><Detail label="Total Bayar" value={formatCurrency(order.amount)} colors={colors} accent="#34D399" /><Detail label="Status Bayar" value={order.payStatus} colors={colors} /></View></View>; }
function Detail({ label, value, colors, accent }: { label: string; value: string; colors: Colors; accent?: string }) { return <View style={styles.detail}><Text style={[styles.detailLabel, { color: colors.muted }]}>{label}</Text><Text style={[styles.detailValue, { color: accent ?? colors.text }]} numberOfLines={1}>{value}</Text></View>; }
function nextStatus(status: OrderStatus): OrderStatus { return status === "Proses" ? "Selesai" : status === "Selesai" ? "Sudah Diambil" : "Proses"; }
function confirmDelete(message: string, onConfirm: () => void) { Alert.alert("Konfirmasi", message, [{ text: "Batal", style: "cancel" }, { text: "Hapus", style: "destructive", onPress: onConfirm }]); }

const styles = StyleSheet.create({
  fill: { flex: 1 }, listContent: { padding: 20, paddingBottom: 104, gap: 12 }, metricsRow: { flexDirection: "row", gap: 8 }, smallMetric: { flex: 1, minHeight: 105, borderRadius: 17, borderWidth: 1, padding: 11, gap: 6 }, metricLabel: { fontSize: 9, fontWeight: "800", letterSpacing: 0.55 }, smallMetricValue: { fontSize: 14, fontWeight: "800" }, featureMetric: { borderWidth: 1, padding: 16, borderRadius: 20, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, featureMetricValue: { fontSize: 22, fontWeight: "800", marginTop: 4 }, sectionHeader: { marginTop: 8, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, sectionTitle: { fontSize: 17, fontWeight: "800" }, roundAction: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center" }, search: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 11, fontSize: 13, marginTop: 2 }, chipRow: { gap: 8, paddingVertical: 2 }, filterRow: { flexDirection: "row", gap: 8 }, choiceChip: { borderRadius: 99, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 8 }, choiceText: { fontSize: 11, fontWeight: "700" }, wrapRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, rowCard: { borderWidth: 1, borderRadius: 18, padding: 12, flexDirection: "row", alignItems: "center", gap: 10 }, iconBox: { height: 42, width: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" }, rowContent: { flex: 1, gap: 2 }, rowTitle: { fontSize: 13, fontWeight: "800" }, rowSub: { fontSize: 11, lineHeight: 16 }, iconButton: { padding: 4 }, empty: { minHeight: 132, borderWidth: 1, borderRadius: 18, alignItems: "center", justifyContent: "center", padding: 20, gap: 10 }, centerMuted: { fontSize: 12, textAlign: "center", lineHeight: 18 }, orderCard: { borderWidth: 1, borderRadius: 18, padding: 14, gap: 5 }, orderTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }, orderId: { fontSize: 13, fontWeight: "800" }, statusPill: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 99 }, statusText: { fontSize: 10, fontWeight: "800" }, orderName: { fontSize: 14, fontWeight: "800", marginTop: 4 }, orderFooter: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 7 }, orderAmount: { fontSize: 14, fontWeight: "800" }, payStatus: { fontSize: 11, fontWeight: "800" }, trackingHero: { borderWidth: 1, borderRadius: 22, padding: 20, alignItems: "center", gap: 10 }, trackingIcon: { height: 58, width: 58, borderRadius: 18, alignItems: "center", justifyContent: "center" }, primaryWide: { minHeight: 47, borderRadius: 14, alignItems: "center", justifyContent: "center", marginTop: 2 }, primaryWideText: { color: "#07111F", fontSize: 13, fontWeight: "800" }, trackingCard: { borderWidth: 1, borderRadius: 18, padding: 14, gap: 12 }, detailsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 12, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: "#334155", paddingTop: 12 }, detail: { width: "46%", gap: 3 }, detailLabel: { fontSize: 10 }, detailValue: { fontSize: 12, fontWeight: "800" }, sheetOverlay: { flex: 1, justifyContent: "flex-end" }, backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(2, 6, 23, 0.62)" }, sheet: { maxHeight: "90%", borderTopLeftRadius: 26, borderTopRightRadius: 26, borderWidth: 1, borderBottomWidth: 0, overflow: "hidden" }, sheetHeader: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, sheetTitle: { fontSize: 18, fontWeight: "800" }, closeButton: { width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center" }, sheetContent: { padding: 20, paddingTop: 8, paddingBottom: 42, gap: 12 }, field: { gap: 6 }, label: { fontSize: 10, fontWeight: "800", letterSpacing: 0.55, textTransform: "uppercase" }, input: { minHeight: 44, borderWidth: 1, borderRadius: 13, paddingHorizontal: 13, fontSize: 13 }, textarea: { minHeight: 76, textAlignVertical: "top", paddingTop: 11 }, totalBox: { borderWidth: 1, borderRadius: 16, padding: 14, gap: 4 }, totalValue: { fontSize: 22, fontWeight: "800" }, pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
});
